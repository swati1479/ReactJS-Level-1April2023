import React from 'react';
class Welcome extends React.Component{
    render(){
        return <h1>Hello Swati, This is React!!
            <p>Hi {this.props.name}</p>
        </h1>
    }
}
Welcome.defaultProps={name:'ABC'}
export default Welcome;