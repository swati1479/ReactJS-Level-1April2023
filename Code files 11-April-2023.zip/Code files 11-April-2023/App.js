import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';

function App(props) {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <h2> Welcome {props.fname}</h2>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <Welcome name='Manisha'/>
        <Welcome/>
      </header>
    </div>
  );
}

export default App;
